import java.util.Random;
import java.util.Scanner;

public class JogoImparOuPar {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            Random random = new Random();
            
            System.out.println("=== Jogo de Ímpar ou Par ===");
            
            // Escolha do usuário
            System.out.print("Escolha Ímpar ou Par (I/P): ");
            String escolhaUsuario = scanner.next().trim().toUpperCase();
            
            while (!escolhaUsuario.equals("I") && !escolhaUsuario.equals("P")) {
                System.out.print("Opção inválida. Digite 'I' para Ímpar ou 'P' para Par: ");
                escolhaUsuario = scanner.next().trim().toUpperCase();
            }
            
            // Número do usuário
            System.out.print("Escolha um número entre 0 e 10: ");
            int numeroUsuario = scanner.nextInt();
            
            while (numeroUsuario < 0 || numeroUsuario > 10) {
                System.out.print("Número inválido. Escolha entre 0 e 10: ");
                numeroUsuario = scanner.nextInt();
            }
            
            // Número do computador
            int numeroComputador = random.nextInt(11); // de 0 a 10
            
            int soma = numeroUsuario + numeroComputador;
            boolean resultadoPar = soma % 2 == 0;
            
            // Resultado
            System.out.println("\nVocê escolheu: " + numeroUsuario);
            System.out.println("Computador escolheu: " + numeroComputador);
            System.out.println("Soma: " + soma + " => " + (resultadoPar ? "Par" : "Ímpar"));
            
            if ((resultadoPar && escolhaUsuario.equals("P")) || (!resultadoPar && escolhaUsuario.equals("I"))) {
                System.out.println("🎉 Você ganhou!");
            } else {
                System.out.println("😞 Você perdeu.");
            }
        }
    }
}

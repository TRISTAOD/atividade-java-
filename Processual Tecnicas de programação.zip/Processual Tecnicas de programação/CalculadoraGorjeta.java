import java.util.Scanner;

public class CalculadoraGorjeta {
    public static void main(String[] args) {
        // Solicita o valor da conta
        try (Scanner scanner = new Scanner(System.in)) {
            // Solicita o valor da conta
            System.out.print("Digite o valor da conta: R$ ");
            double valorConta = scanner.nextDouble();
            
            // Solicita a porcentagem da gorjeta
            System.out.print("Digite a porcentagem da gorjeta (%): ");
            double porcentagemGorjeta = scanner.nextDouble();
            
            // Calcula o valor da gorjeta
            double valorGorjeta = valorConta * (porcentagemGorjeta / 100);
            
            // Calcula o total a pagar
            double total = valorConta + valorGorjeta;
            
            // Exibe os resultados
            System.out.printf("Gorjeta: R$ %.2f\n", valorGorjeta);
            System.out.printf("Total a pagar: R$ %.2f\n", total);
        }
    }
}


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.awt.Desktop;

public class CalculadoraCombustivel {
    public static void main(String[] args) {
        // Entradas do usuário
        try (Scanner scanner = new Scanner(System.in)) {
            // Entradas do usuário
            System.out.print("Digite o preço do litro do combustível (R$): ");
            double precoLitro = scanner.nextDouble();
            System.out.print("Digite o valor abastecido (R$): ");
            double valorAbastecido = scanner.nextDouble();
            System.out.print("Digite o consumo do veículo (km/l): ");
            double consumo = scanner.nextDouble();
            // Cálculos
            double litrosAbastecidos = valorAbastecido / precoLitro;
            double distancia = litrosAbastecidos * consumo;
            // Exibir no console
            System.out.println("\n========= RESUMO DO ABASTECIMENTO =========");
            System.out.printf("Litros abastecidos : %.2f L\n", litrosAbastecidos);
            System.out.printf("Distância estimada : %.2f km\n", distancia);
            System.out.printf("Total gasto        : R$ %.2f\n", valorAbastecido);
            System.out.println("============================================\n");
            // Gerar nome do arquivo com data e hora
            String dataHora = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
            String nomeArquivo = "relatorio_" + dataHora + ".txt";
            File arquivo = new File(nomeArquivo);
            // Salvar e abrir o arquivo
            try (FileWriter writer = new FileWriter(arquivo)) {
                writer.write("========= RELATÓRIO DE ABASTECIMENTO =========\n");
                writer.write(String.format("Preço por litro      : R$ %.2f\n", precoLitro));
                writer.write(String.format("Valor abastecido     : R$ %.2f\n", valorAbastecido));
                writer.write(String.format("Litros abastecidos   : %.2f L\n", litrosAbastecidos));
                writer.write(String.format("Consumo do veículo   : %.2f km/l\n", consumo));
                writer.write(String.format("Distância estimada   : %.2f km\n", distancia));
                writer.write("===============================================\n");
                System.out.println("Relatório salvo como: " + nomeArquivo);
                
                // Abrir o arquivo automaticamente
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(arquivo);
                }
            } catch (IOException e) {
                System.out.println("Erro ao salvar ou abrir o arquivo: " + e.getMessage());
            }
            }
    }
}
